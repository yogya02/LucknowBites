import 'package:flutter/material.dart';

import '../models/food_spot.dart';

class SpotCard extends StatelessWidget {
  final FoodSpot spot;
  final double? distanceMetres;
  final bool openNow;
  final VoidCallback onTap;

  const SpotCard({
    super.key,
    required this.spot,
    required this.distanceMetres,
    required this.openNow,
    required this.onTap,
  });

  String _distanceText() {
    final d = distanceMetres;
    if (d == null) return spot.area;
    if (d < 1000) return '${d.round()} m away';
    return '${(d / 1000).toStringAsFixed(1)} km away';
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Text(spot.name,
                        style: theme.textTheme.titleMedium
                            ?.copyWith(fontWeight: FontWeight.w600)),
                  ),
                  Chip(
                    label: Text(openNow ? 'Open' : 'Closed'),
                    backgroundColor: openNow
                        ? Colors.green.shade100
                        : Colors.red.shade100,
                    visualDensity: VisualDensity.compact,
                  ),
                ],
              ),
              const SizedBox(height: 4),
              Text(spot.dishes.join(', '),
                  style: theme.textTheme.bodyMedium),
              const SizedBox(height: 6),
              Text(
                '${_distanceText()}  |  ${spot.hoursLabel}  |  ${spot.priceRange}',
                style: theme.textTheme.bodySmall,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
