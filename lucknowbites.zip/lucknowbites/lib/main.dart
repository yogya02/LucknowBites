import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';

import 'data/spot_repository.dart';
import 'screens/home_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Use Firebase if the project has been configured; otherwise fall back to
  // the bundled assets/spots.json so the app still runs.
  SpotRepository repository;
  try {
    await Firebase.initializeApp();
    repository = FirestoreSpotRepository();
  } catch (_) {
    repository = AssetSpotRepository();
  }

  runApp(LucknowBitesApp(repository: repository));
}

class LucknowBitesApp extends StatelessWidget {
  final SpotRepository repository;
  const LucknowBitesApp({super.key, required this.repository});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'LucknowBites',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF5B4B9A)),
      ),
      home: HomeScreen(repository: repository),
    );
  }
}
