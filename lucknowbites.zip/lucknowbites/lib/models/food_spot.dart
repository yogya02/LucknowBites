/// One food spot in Lucknow.
class FoodSpot {
  final String id;
  final String name;
  final String area;
  final double latitude;
  final double longitude;
  final List<String> dishes;
  final String priceRange;

  /// Opening and closing time in 24-hour "HH:mm" format.
  /// If [closesAt] is earlier than [opensAt], the spot closes after midnight.
  final String opensAt;
  final String closesAt;
  final bool vegetarian;

  const FoodSpot({
    required this.id,
    required this.name,
    required this.area,
    required this.latitude,
    required this.longitude,
    required this.dishes,
    required this.priceRange,
    required this.opensAt,
    required this.closesAt,
    required this.vegetarian,
  });

  factory FoodSpot.fromMap(String id, Map<String, dynamic> map) {
    return FoodSpot(
      id: id,
      name: map['name'] as String,
      area: (map['area'] ?? '') as String,
      latitude: (map['latitude'] as num).toDouble(),
      longitude: (map['longitude'] as num).toDouble(),
      dishes: List<String>.from(map['dishes'] ?? const <String>[]),
      priceRange: (map['priceRange'] ?? '') as String,
      opensAt: (map['opensAt'] ?? '00:00') as String,
      closesAt: (map['closesAt'] ?? '23:59') as String,
      vegetarian: (map['vegetarian'] ?? false) as bool,
    );
  }

  Map<String, dynamic> toMap() => {
        'name': name,
        'area': area,
        'latitude': latitude,
        'longitude': longitude,
        'dishes': dishes,
        'priceRange': priceRange,
        'opensAt': opensAt,
        'closesAt': closesAt,
        'vegetarian': vegetarian,
      };

  static int _minutes(String hhmm) {
    final parts = hhmm.split(':');
    return int.parse(parts[0]) * 60 + int.parse(parts[1]);
  }

  /// True if the spot is open at [time]. Handles spots that close after midnight.
  bool isOpenAt(DateTime time) {
    final now = time.hour * 60 + time.minute;
    final open = _minutes(opensAt);
    final close = _minutes(closesAt);
    if (open <= close) {
      return now >= open && now < close;
    }
    return now >= open || now < close;
  }

  /// Opening hours as text, for example "11:00 - 23:00".
  String get hoursLabel => '$opensAt - $closesAt';
}
