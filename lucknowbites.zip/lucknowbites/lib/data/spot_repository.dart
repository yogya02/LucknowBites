import 'dart:convert';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/services.dart' show rootBundle;

import '../models/food_spot.dart';

/// Where the app reads food spots from.
abstract class SpotRepository {
  Future<List<FoodSpot>> loadSpots();
}

/// Reads spots from the Firestore collection `spots`.
class FirestoreSpotRepository implements SpotRepository {
  @override
  Future<List<FoodSpot>> loadSpots() async {
    final snapshot = await FirebaseFirestore.instance.collection('spots').get();
    return snapshot.docs.map((d) => FoodSpot.fromMap(d.id, d.data())).toList();
  }
}

/// Reads spots from `assets/spots.json`. Used when Firebase is not set up,
/// so the app still runs for anyone who clones the repository.
class AssetSpotRepository implements SpotRepository {
  @override
  Future<List<FoodSpot>> loadSpots() async {
    final raw = await rootBundle.loadString('assets/spots.json');
    final list = jsonDecode(raw) as List<dynamic>;
    return list
        .map((e) => FoodSpot.fromMap(
              (e as Map<String, dynamic>)['id'] as String,
              e,
            ))
        .toList();
  }
}
