import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../models/food_spot.dart';

class SpotDetailScreen extends StatelessWidget {
  final FoodSpot spot;
  const SpotDetailScreen({super.key, required this.spot});

  Future<void> _openDirections(BuildContext context) async {
    // Opens Google Maps with walking directions from the user's location.
    final uri = Uri.parse(
      'https://www.google.com/maps/dir/?api=1'
      '&destination=${spot.latitude},${spot.longitude}'
      '&travelmode=walking',
    );
    final ok = await launchUrl(uri, mode: LaunchMode.externalApplication);
    if (!ok && context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Could not open Google Maps.')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final open = spot.isOpenAt(DateTime.now());
    return Scaffold(
      appBar: AppBar(title: Text(spot.name)),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Text(spot.area, style: theme.textTheme.titleMedium),
          const SizedBox(height: 16),
          Text('What to order', style: theme.textTheme.titleSmall),
          const SizedBox(height: 6),
          Wrap(
            spacing: 8,
            runSpacing: 4,
            children:
                spot.dishes.map((d) => Chip(label: Text(d))).toList(),
          ),
          const SizedBox(height: 20),
          _row(Icons.payments_outlined, 'Price range', spot.priceRange),
          _row(Icons.schedule, 'Opening hours', spot.hoursLabel),
          _row(Icons.circle, 'Right now', open ? 'Open' : 'Closed'),
          _row(Icons.eco_outlined, 'Vegetarian options',
              spot.vegetarian ? 'Yes' : 'No'),
          const SizedBox(height: 24),
          FilledButton.icon(
            onPressed: () => _openDirections(context),
            icon: const Icon(Icons.directions_walk),
            label: const Text('Walking directions'),
          ),
        ],
      ),
    );
  }

  Widget _row(IconData icon, String label, String value) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 6),
        child: Row(
          children: [
            Icon(icon, size: 20),
            const SizedBox(width: 12),
            Text('$label: ', style: const TextStyle(fontWeight: FontWeight.w600)),
            Expanded(child: Text(value)),
          ],
        ),
      );
}
