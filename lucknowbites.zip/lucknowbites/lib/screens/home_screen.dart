import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

import '../data/spot_repository.dart';
import '../models/food_spot.dart';
import '../services/location_service.dart';
import '../widgets/spot_card.dart';
import 'spot_detail_screen.dart';

class HomeScreen extends StatefulWidget {
  final SpotRepository repository;
  const HomeScreen({super.key, required this.repository});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  static const LatLng _lucknow = LatLng(26.8467, 80.9462);

  final _location = LocationService();
  List<FoodSpot> _spots = [];
  Position? _position;
  bool _loading = true;
  String? _error;

  bool _vegOnly = false;
  bool _openNowOnly = false;
  int _tab = 0; // 0 = list, 1 = map

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final spots = await widget.repository.loadSpots();
      final pos = await _location.currentPosition();
      if (!mounted) return;
      setState(() {
        _spots = spots;
        _position = pos;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _error = 'Could not load food spots. Please try again.';
        _loading = false;
      });
    }
  }

  double? _distanceTo(FoodSpot s) {
    final p = _position;
    if (p == null) return null;
    return _location.distanceMetres(
        p.latitude, p.longitude, s.latitude, s.longitude);
  }

  /// Applies the filters and sorts by distance (when location is known).
  List<FoodSpot> get _visible {
    final now = DateTime.now();
    final list = _spots.where((s) {
      if (_vegOnly && !s.vegetarian) return false;
      if (_openNowOnly && !s.isOpenAt(now)) return false;
      return true;
    }).toList();
    if (_position != null) {
      list.sort((a, b) => _distanceTo(a)!.compareTo(_distanceTo(b)!));
    }
    return list;
  }

  void _open(FoodSpot s) {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => SpotDetailScreen(spot: s)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('LucknowBites'),
        actions: [
          IconButton(
            tooltip: 'Reload',
            onPressed: _load,
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      body: Column(
        children: [
          _filters(),
          Expanded(child: _content()),
        ],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: (i) => setState(() => _tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.list), label: 'List'),
          NavigationDestination(icon: Icon(Icons.map_outlined), label: 'Map'),
        ],
      ),
    );
  }

  Widget _filters() => Padding(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        child: Row(
          children: [
            FilterChip(
              label: const Text('Vegetarian'),
              selected: _vegOnly,
              onSelected: (v) => setState(() => _vegOnly = v),
            ),
            const SizedBox(width: 8),
            FilterChip(
              label: const Text('Open now'),
              selected: _openNowOnly,
              onSelected: (v) => setState(() => _openNowOnly = v),
            ),
          ],
        ),
      );

  Widget _content() {
    if (_loading) return const Center(child: CircularProgressIndicator());
    if (_error != null) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(_error!),
            const SizedBox(height: 8),
            FilledButton(onPressed: _load, child: const Text('Try again')),
          ],
        ),
      );
    }
    final spots = _visible;
    if (spots.isEmpty) {
      return const Center(child: Text('No spots match these filters.'));
    }
    return _tab == 0 ? _list(spots) : _map(spots);
  }

  Widget _list(List<FoodSpot> spots) {
    final now = DateTime.now();
    return ListView.builder(
      itemCount: spots.length,
      itemBuilder: (_, i) {
        final s = spots[i];
        return SpotCard(
          spot: s,
          distanceMetres: _distanceTo(s),
          openNow: s.isOpenAt(now),
          onTap: () => _open(s),
        );
      },
    );
  }

  Widget _map(List<FoodSpot> spots) {
    final start = _position != null
        ? LatLng(_position!.latitude, _position!.longitude)
        : _lucknow;
    final markers = spots
        .map((s) => Marker(
              markerId: MarkerId(s.id),
              position: LatLng(s.latitude, s.longitude),
              infoWindow: InfoWindow(
                title: s.name,
                snippet: s.dishes.take(2).join(', '),
                onTap: () => _open(s),
              ),
            ))
        .toSet();
    return GoogleMap(
      initialCameraPosition: CameraPosition(target: start, zoom: 13),
      markers: markers,
      myLocationEnabled: _position != null,
      myLocationButtonEnabled: _position != null,
    );
  }
}
