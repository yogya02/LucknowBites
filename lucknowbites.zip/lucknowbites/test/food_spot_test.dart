import 'package:flutter_test/flutter_test.dart';
import 'package:lucknowbites/models/food_spot.dart';

FoodSpot _spot(String open, String close) => FoodSpot(
      id: 't',
      name: 'Test',
      area: 'Test',
      latitude: 0,
      longitude: 0,
      dishes: const ['x'],
      priceRange: 'Rs. 100',
      opensAt: open,
      closesAt: close,
      vegetarian: false,
    );

void main() {
  group('isOpenAt', () {
    test('open during the day', () {
      final s = _spot('11:00', '23:00');
      expect(s.isOpenAt(DateTime(2026, 1, 1, 12, 0)), isTrue);
      expect(s.isOpenAt(DateTime(2026, 1, 1, 10, 59)), isFalse);
      expect(s.isOpenAt(DateTime(2026, 1, 1, 23, 0)), isFalse);
    });

    test('handles spots that close after midnight', () {
      final s = _spot('18:00', '01:00');
      expect(s.isOpenAt(DateTime(2026, 1, 1, 23, 30)), isTrue);
      expect(s.isOpenAt(DateTime(2026, 1, 1, 0, 30)), isTrue);
      expect(s.isOpenAt(DateTime(2026, 1, 1, 12, 0)), isFalse);
    });
  });

  test('fromMap reads all fields', () {
    final s = FoodSpot.fromMap('a1', {
      'name': 'Stall',
      'area': 'Aminabad',
      'latitude': 26.84,
      'longitude': 80.93,
      'dishes': ['galouti kebab'],
      'priceRange': 'Rs. 100-300',
      'opensAt': '12:00',
      'closesAt': '23:00',
      'vegetarian': false,
    });
    expect(s.id, 'a1');
    expect(s.dishes, ['galouti kebab']);
    expect(s.latitude, 26.84);
  });
}
